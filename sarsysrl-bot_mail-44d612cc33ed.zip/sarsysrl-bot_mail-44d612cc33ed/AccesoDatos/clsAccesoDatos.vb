﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class ClsAccesoDatos


    Private ConnString As String
    Private SqlConn As SqlConnection



    Public Sub New()
        Me.ConnString = ConfigurationManager.ConnectionStrings("CSDBEVALAPP").ConnectionString.ToString()
    End Sub


    Public Function ExecuteSP(ByVal strSP As String, Optional ByVal paramList As Dictionary(Of String, String) = Nothing, Optional ByRef stResult As String = "") As DataSet
        Dim ds As New DataSet
        Dim da As New SqlDataAdapter
        Try
            Me.SqlConn = New SqlConnection(Me.ConnString)
            Using Me.SqlConn
                ds = New DataSet()
                da = New SqlDataAdapter()

                Dim cmd As New SqlCommand(strSP)
                cmd.Connection = Me.SqlConn
                cmd.CommandType = CommandType.StoredProcedure
                da.SelectCommand = cmd

                If Not paramList Is Nothing Then
                    For Each item In paramList
                        cmd.Parameters.AddWithValue("@" + item.Key, item.Value)
                    Next
                End If
                'If Not user Is Nothing Then
                '    cmd.Parameters.AddWithValue("@User", user.email)
                'End If
                da.Fill(ds)
                Me.SqlConn.Close()

            End Using

            Dim tableNumber As Integer

            tableNumber = ds.Tables.Count - 1

            Dim hasRows As Boolean = False


            For i As Integer = 0 To tableNumber
                If ds.Tables(i).Rows.Count > 0 Then
                    hasRows = True
                End If
            Next


            If ds.Tables.Count > 0 Then
                'stResult = ds.Tables(tableNumber).Rows(0).Item(0).ToString
                stResult = "OK"
                Return ds
            Else
                Dim nds As New DataSet()
                nds.Tables.Add(New DataTable())
                stResult = "ERROR"
                Return nds
            End If
        Catch ex As Exception
            'clsComun.GenerateLOG("log.log", "clsDB - ExecuteSP - Exception: " + ex.Message)
            Dim nds As New DataSet()
            nds.Tables.Add(New DataTable())
            stResult = "ERROR"
            Return nds
        End Try
    End Function

    Public Function ExecuteQuery(ByVal strQuery As String, ByRef strResult As String) As DataSet

        Dim ds As Data.DataSet = Nothing
        Dim da As SqlDataAdapter
        Try
            Me.SqlConn = New SqlConnection(Me.ConnString)
            Using Me.SqlConn
                ds = New DataSet
                da = New SqlDataAdapter

                Dim cmd As New SqlCommand(strQuery)
                cmd.Connection = Me.SqlConn
                cmd.CommandType = CommandType.Text
                da.SelectCommand = cmd


                da.Fill(ds)

                strResult = "OK"

                da.Dispose()
                cmd.Dispose()
                Me.SqlConn.Close()
                Me.SqlConn.Dispose()
            End Using

        Catch ex As Exception
            strResult = ex.Message
        End Try

        Return ds
    End Function


End Class
