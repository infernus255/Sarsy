## [v1.0.0.0] Start 11/11/2019

### Added

-Carga inicial del proyecto
	-Clase para enviar mails(escritorio)
	-Windows Form para ejecutar enviar los mails
	-Clase para acceder a la base de datos