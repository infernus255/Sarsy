# TITULO
-BOT MAIL
## EMPEZANDO
-Bot mail es una aplicacion escrita en VB.NET, se encarga de enviar mails a los empleados y jefes determinados por los datos de los 
store procedure que son pasados a las clases especificas. Al enviar un mail queda un registro de a quien se le envio en una tabla 
log_mails. La aplicacion se ejecutara a cierta hora dependiendo de como fue configurada desde las tareas programadas de windows.
### REQUISITOS
-Una base de datos que devuelva los mails a enviar y guarde logs de los mismos.
-Programar su ejecucion mediante tareas programadas de windows.
-Cualquier template que se quiera agregar se debera escribir en html e insertar en la carpeta de templates anadiendo la etiqueta 
<nombreColumna> escrita en el template para reemplazar por los datos de base de datos.
#### INSTALACION
-Se debe modificar el App.Config para que conecte con la base de datos a utilizar.
Por ejemplo  
 <connectionStrings>
    <add name="CSDBEVALAPP" connectionString="Data Source=localhost;Initial Catalog=JOB_DESCRIPTION;Integrated Security=True;Language=Spanish;" providerName="System.Data.SqlClient"/>
  </connectionStrings>
La misma se accedera de la siguiente manera
	Me.ConnString = ConfigurationManager.ConnectionStrings("CSDBEVALAPP").ConnectionString.ToString()

## TEST
-Las pruebas se estan realizando a traves de mails temporales creados por MAILINATOR