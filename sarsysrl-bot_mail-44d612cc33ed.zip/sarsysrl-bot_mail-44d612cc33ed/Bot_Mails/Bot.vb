﻿Imports System.Configuration
Imports Negocio.ClsMail

Public Class Bot
    Private Sub btnEnviar_Click(sender As Object, e As EventArgs) Handles btnEnviar.Click

        Dim paramList As New Dictionary(Of String, String)

        'vencimiento empleado
        '1 dia
        Try
            paramList.Add("op", "vencimiento_empleado")
            paramList.Add("dias", Integer.Parse(ConfigurationManager.AppSettings("DIAS_VENCIMIENTO_EMPLEADO").ToString))

            Negocio.ClsMail.avisoMail("SP_JD_Consultar_Mail", paramList, "info@vaiu-jobdescription.com", "Equipo Vaiu Job Description", "info2019", "mail.vaiu-jobdescription.com", True, False)
            paramList.Clear()

            'vencio empleado jefe
            'sin dias
            paramList.Add("op", "vencio_empleado_jefe")
            paramList.Add("dias", 0)

            Negocio.ClsMail.avisoMail("SP_JD_Consultar_Mail", paramList, "info@vaiu-jobdescription.com", "Equipo Vaiu Job Description", "info2019", "mail.vaiu-jobdescription.com", True, True)
            paramList.Clear()

            'vencimiento aprobacion jefe
            '1 dia
            paramList.Add("op", "vencimiento_aprobacion_jefe")
            paramList.Add("dias", Integer.Parse(ConfigurationManager.AppSettings("DIAS_VENCIMIENTO_APROBACION_JEFE").ToString))

            Negocio.ClsMail.avisoMail("SP_JD_Consultar_Mail", paramList, "info@vaiu-jobdescription.com", "Equipo Vaiu Job Description", "info2019", "mail.vaiu-jobdescription.com", True, True)
            paramList.Clear()

            'reabrir_formulario_empleado_jefe
            '365 dias

            paramList.Add("op", "reabrir_formulario_empleado_jefe")
            paramList.Add("dias", Integer.Parse(ConfigurationManager.AppSettings("DIAS_REAPERTURA_FORMULARIO_EMPLEADO_JEFE").ToString))

            Negocio.ClsMail.avisoMail("SP_JD_Consultar_Mail", paramList, "info@vaiu-jobdescription.com", "Equipo Vaiu Job Description", "info2019", "mail.vaiu-jobdescription.com", True, True)
            paramList.Clear()

            MessageBox.Show("enviado")

        Catch ex As Exception
            GenerateLOG("log.txt", Date.Now & " btnEnviar_Click: " & ex.ToString)
        End Try

    End Sub

    Private Sub Bot_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim stPAram As String

        Try

            If UBound(Environment.GetCommandLineArgs()) > 0 Then

                stPAram = Environment.GetCommandLineArgs(1)
                If stPAram = "AUTO" Then
                    'Ejecuta el boton
                    'cierra el bot
                    btnEnviar.PerformClick()
                    Close()
                End If
            End If

        Catch ex As Exception
            GenerateLOG("log.txt", Date.Now & " Bot_Load: " & ex.ToString)
        End Try
    End Sub
End Class