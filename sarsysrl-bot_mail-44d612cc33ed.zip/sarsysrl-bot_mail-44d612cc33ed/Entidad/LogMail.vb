﻿Public Class LogMail

    Private email As String
    Private tipo As Integer
    Private idFormulario As Integer
    Private idEmpleado As Integer
    Private idJefe As Integer
    Private fecha As Date
    Private estado As Boolean
    Public Property getSetEstado() As Boolean
        Get
            Return estado
        End Get
        Set(ByVal value As Boolean)
            estado = value
        End Set
    End Property

    Public Property getSetFecha() As Date
        Get
            Return fecha
        End Get
        Set(ByVal value As Date)
            fecha = value
        End Set
    End Property
    Public Property getSetIdJefe() As Integer
        Get
            Return idJefe
        End Get
        Set(ByVal value As Integer)
            idJefe = value
        End Set
    End Property
    Public Property getSetIdEmpleado() As Integer
        Get
            Return idEmpleado
        End Get
        Set(ByVal value As Integer)
            idEmpleado = value
        End Set
    End Property
    Public Property getSetIdFormulario() As Integer
        Get
            Return idFormulario
        End Get
        Set(ByVal value As Integer)
            idFormulario = value
        End Set
    End Property

    Public Property getSetTipo() As Integer
        Get
            Return tipo
        End Get
        Set(ByVal value As Integer)
            tipo = value
        End Set
    End Property

    Public Property getSetEmail() As String
        Get
            Return email
        End Get
        Set(ByVal value As String)
            email = value
        End Set
    End Property

    Public Sub New()
        'constructor
        Me.email = ""
        Me.tipo = 0
        Me.idFormulario = 0
        Me.idEmpleado = 0
        Me.idJefe = 0
        Me.fecha = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Me.estado = True
    End Sub

    Public Sub New(ByVal email As String, ByVal tipo As Integer, ByVal idFormulario As Integer, ByVal idEmpleado As Integer, ByVal idJefe As Integer)
        'constructor con parametros
        Me.email = email
        Me.tipo = tipo
        Me.idFormulario = idFormulario
        Me.idEmpleado = idEmpleado
        Me.idJefe = idJefe
        Me.fecha = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Me.estado = True
    End Sub

End Class
