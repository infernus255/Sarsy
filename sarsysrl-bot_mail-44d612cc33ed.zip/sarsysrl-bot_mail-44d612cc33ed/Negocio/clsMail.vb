﻿Imports System.IO
Imports System.Net.Mail
Imports AccesoDatos
Imports Entidad

Public Class ClsMail

    Public Shared Function EnvioMail(ByVal correoRemitente As String,
                     ByVal nombreRemitente As String,
                     ByVal passRemitente As String,
                     ByVal correoDestinatario As String,
                     ByVal asunto As String,
                     ByVal mensaje As String,
                     ByVal host As String,
                     ByVal isHtml As Boolean)


        Dim correo As New MailMessage

        Dim smtp As New SmtpClient()

        Dim rst As String = ""

        Try
            correo.From = New MailAddress(correoRemitente, nombreRemitente, System.Text.Encoding.UTF8)

            correo.To.Add(correoDestinatario)

            correo.SubjectEncoding = System.Text.Encoding.UTF8

            correo.Subject = asunto

            correo.Body = mensaje

            correo.BodyEncoding = System.Text.Encoding.UTF8

            correo.IsBodyHtml = isHtml '(formato tipo web o normal:   true = web)

            correo.Priority = MailPriority.High ' prioridad


            smtp.Credentials = New System.Net.NetworkCredential(correoRemitente, passRemitente)

            smtp.Port = 25

            smtp.Host = host

            smtp.EnableSsl = False

            smtp.Send(correo)

            rst = "OK"
            Return rst

        Catch ex As Exception
            GenerateLOG("log.txt", Date.Now & " EnvioMail: " & ex.ToString)
            Return rst
        End Try

    End Function

    Public Shared Function avisoMail(
                     ByVal sp As String,
                     ByVal paramList As Dictionary(Of String, String),
                     ByVal correoRemitente As String,
                     ByVal nombreRemitente As String,
                     ByVal passRemitente As String,
                     ByVal host As String,
                     ByVal isHtml As Boolean,
                     ByVal isJefe As Boolean)

        Dim DB As New ClsAccesoDatos
        Dim rst As String = ""
        Dim ds As New DataSet

        Try



            ds = DB.ExecuteSP(sp, paramList, rst)

            'si el ds tiene datos
            If (ds.Tables(0).Rows.Count > 0) Then
                'recorro cada fila

                For Each x As DataRow In ds.Tables(0).Rows
                    'Dim fileReader As String
                    Dim stAsunto As String
                    Dim stBody As String
                    Dim email As String
                    Dim lm As New LogMail()



                    stBody = My.Computer.FileSystem.ReadAllText((Replace(My.Application.Info.DirectoryPath, "\bin\Debug", "") & x("plantilla")))
                    stAsunto = x("asunto")

                    For i = 0 To x.ItemArray.Count - 1
                        stBody = Replace(stBody, "<" & ds.Tables(0).Columns(i).ColumnName & ">", x.ItemArray(i))
                        stAsunto = Replace(stAsunto, "<" & ds.Tables(0).Columns(i).ColumnName & ">", x.ItemArray(i))
                    Next

                    'si es jefe usa id empleado y jefe y email de jefe, si no es jefe usa email empleado y id empleado
                    If (isJefe) Then
                        email = "emailJefe"
                        lm.getSetIdEmpleado = x("idEmpleado")
                        lm.getSetIdJefe = x("idJefe")
                    Else
                        email = "emailEmpleado"
                        lm.getSetIdEmpleado = x("idEmpleado")
                    End If

                    lm.getSetEmail = x(email)
                    lm.getSetTipo = x("tipo")
                    lm.getSetIdFormulario = x("idFormulario")

                    'envio un mail por cada fila en la columna mail
                    rst = EnvioMail(correoRemitente, nombreRemitente, passRemitente, x(email).ToString, stAsunto, stBody, host, isHtml)

                    'si se envio correctamente el mail genero un log en la db
                    If (rst = "OK") Then
                        rst = generateLogMail(lm)
                    End If



                Next

            End If

            Return rst
        Catch ex As Exception
            GenerateLOG("log.txt", Date.Now & " avisoMail: " & ex.ToString)
            Return rst
        End Try

    End Function

    Public Shared Function generateLogMail(x As LogMail)

        Dim DB As New ClsAccesoDatos
        Dim rst As String = ""

        Try
            DB.ExecuteQuery("insert into tbl_JD_Log_Mails (email,tipo,idFormulario,idEmpleado,idJefe,fecha,estado) values('" & x.getSetEmail & "'," & IIf(x.getSetTipo = 0, "NULL", x.getSetTipo) & "," & IIf(x.getSetIdFormulario = 0, "NULL", x.getSetIdFormulario) & "," & IIf(x.getSetIdEmpleado = 0, "NULL", x.getSetIdEmpleado) & "," & IIf(x.getSetIdJefe = 0, "NULL", x.getSetIdJefe) & ",'" & x.getSetFecha & "'," & IIf(x.getSetEstado = True, 1, 0) & ")", rst)
            Return rst


        Catch ex As Exception
            GenerateLOG("log.txt", Date.Now & " generateLogMail: " & ex.ToString)
            Return rst
        End Try



    End Function

    Public Shared Sub GenerateLOG(ByVal stFile As String, ByVal stError As String)
        Dim gPATH_APP As String = Replace(My.Application.Info.DirectoryPath, "\bin\Debug", "") & "\logs\"
        Dim swFile As StreamWriter

        Try
            stFile = gPATH_APP & stFile
            swFile = New StreamWriter(stFile, True)
            swFile.Write(CStr(Now) & "-" & stError & vbCrLf)
            swFile.Close()
        Catch
        End Try
    End Sub

End Class
