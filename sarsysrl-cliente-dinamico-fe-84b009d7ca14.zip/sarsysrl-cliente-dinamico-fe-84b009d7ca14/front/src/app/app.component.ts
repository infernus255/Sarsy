import { Component } from '@angular/core';
import { NavigationEnd, Router, RouteReuseStrategy } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Api Dinamica';


 getLogged(){
  return localStorage.getItem('auth_token');
 }

 logout(){
  localStorage.setItem('auth_token'," ");
  let router : Router;
  router.navigate([" "])
 }


}
