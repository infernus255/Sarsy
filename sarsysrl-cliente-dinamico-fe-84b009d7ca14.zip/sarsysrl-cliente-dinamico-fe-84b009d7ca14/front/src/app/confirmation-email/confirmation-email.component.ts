import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmation-email',
  templateUrl: './confirmation-email.component.html',
  styleUrls: ['./confirmation-email.component.css']
})
export class ConfirmationEmailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
