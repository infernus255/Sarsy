export class User {
    email : string;
    name : string;
    surname: string;
    dni: string;
    password: string;

    User(){
        this.name= '';
        this.surname= '';
        this.dni= '';
        this.password= '';
        this.email= '';
    }


}
