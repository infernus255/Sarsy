import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ListComponent } from './list/list.component';
import { UserComponent } from './user/user.component';
import { LoginComponent} from './login/login.component';
import { ConfirmationEmailComponent } from './confirmation-email/confirmation-email.component'

const routes: Routes = [
          { path: 'list', component: ListComponent },
          { path: 'user', component: UserComponent },
          { path: 'login', component: LoginComponent },
          { path:'', component: LoginComponent },
          { path: 'confirmation', component: ConfirmationEmailComponent } 
        ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
