import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from '../auth.service';
import Swal from 'sweetalert2';
import { ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/filter';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  closeResult: string;
  userName: string = '';
  password: string = '';
  queryParam: string = '';

  constructor(private modalService: NgbModal, private router: Router,
     private AuthService: AuthService,
     private route: ActivatedRoute) { }

  IsLogged: Boolean = false;

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.queryParam = params['token'];
  });
  if(this.queryParam)
  {
    this.confirmation();
  }

    localStorage.setItem("auth_token", " ");
  }

  open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }


  logIn(event: Event) {
    event.preventDefault();
    this.AuthService.Login(this.userName, this.password).subscribe((res) => {
      if (localStorage.getItem("auth_token") != " ") {
        this.IsLogged = true;
      }
      if (this.IsLogged) {
        this.navigate();
      }
    }, err => {
      Swal.fire({
        title: 'Error!',
        text: 'Usuario o contraseña incorrectos',
        icon: 'error',
        confirmButtonText: 'Ok'
      })
    });
  }

  confirmation() {
    this.router.navigate(['/confirmation'], { queryParamsHandling: 'preserve' });
  }

  navigate() {
    this.router.navigate(['/list']);
  }

  getLogged() {
    return localStorage.getItem('auth_token');
  }
}
