import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  apiURL: string = 'https://localhost:44376/api/';

  constructor(public httpClient: HttpClient) { }

  Login(Username: string, password: string) {
    let httpHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
    });
    let httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json', }), responseType: 'text' as 'json' };
    return this.httpClient.post(`${this.apiURL}Auth/Login`, {
      "UserName": Username,
      "password": password
    }, httpOptions)
      .map(res => {
        localStorage.setItem('auth_token', res.toString());
      });
  }

  ConfirmationEmail(token: string, email:string){
    let httpHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
    });
    let httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json', }), responseType: 'text' as 'json' };
    return this.httpClient.post(`${this.apiURL}User/ConfirmEmail`, {
      "token": token,
      "email":email,
    }, httpOptions);
  }

  logout() {
    localStorage.removeItem('auth_token');
  }




}
