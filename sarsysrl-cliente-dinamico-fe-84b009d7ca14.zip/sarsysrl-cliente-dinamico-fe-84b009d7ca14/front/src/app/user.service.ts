import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './user';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  apiURL: string = 'https://localhost:44376/api/';

  constructor(public httpClient: HttpClient) { }

  GetUsers(): Observable<any> {
    return this.httpClient.get(`${this.apiURL}User/GetUsers`);
  }

  AddUser(user: User): Observable<User> {
    let httpHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
    });
    let options = {
      headers: httpHeaders
    };
    return this.httpClient.post<User>(`${this.apiURL}User/CreateUser`, user, options);
  }

}
