import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { UserService } from '../user.service'
import { User } from '../user';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  closeResult: string;
  Users: Array<User>;
  constructor(private modalService: NgbModal, private UserService: UserService, private router: Router) { }

  ngOnInit(): void {
    let logged = localStorage.getItem('auth_token');
    if(logged ==" ")
    {
      this.router.navigate(["/login"])
    }
    this.getUsers();
  }

  open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  getUsers() {
    this.UserService.GetUsers().subscribe((res: User[]) => {
      console.log(res);
      this.Users = res;
      console.log(this.Users);
    });
  };

}
