﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Servicios;
using Servicios.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Cliente_Dinamico_Api.Models.Input;
using AutoMapper;
using Entidades;
using Servicios.Email;

namespace Cliente_Dinamico_Api.Controllers
{

    [AllowAnonymous]
    [Route("api/[controller]/[action]")]
    public class AuthController : Controller
    {
        private readonly IAuthService _authService;
        private readonly IEmailSender _emailSender;
        public AuthController(IAuthService authService, IEmailSender emailSender)
        {
            _authService = authService;
            _emailSender = emailSender;
        }

        [HttpPost]
        public async Task<string> Login([FromBody] LoginDto loginDto)
        {
            return await _authService.LoginAsync(loginDto.UserName, loginDto.Password);
        }

  
        [HttpGet]
        public IEnumerable<User> Email()
        {
            var message = new Message(new string[] { "matias.aguero@sarsy-srl.com" }, "Test email", "This is the content from our email.");
            _emailSender.SendEmail(message);

            return Enumerable.Range(1, 5).Select(index => new User
            {
                Name = "xd",
                Email = "xd2",
                //Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }


    }
}
