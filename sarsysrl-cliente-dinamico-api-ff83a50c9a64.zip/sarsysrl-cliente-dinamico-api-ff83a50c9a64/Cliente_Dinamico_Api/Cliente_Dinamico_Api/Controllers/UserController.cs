﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Servicios;
using Servicios.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Cliente_Dinamico_Api.Models.Input;
using AutoMapper;
using Entidades;
using Microsoft.AspNetCore.Identity;
using Servicios.Email;

namespace Cliente_Dinamico_Api.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]/[action]")]
    public class UserController : Controller
    {
        private readonly IUserService _userService;
        private readonly IMapper _mapper;
        private readonly UserManager<User> _userManager;
        private readonly IEmailSender _emailSender;


        public UserController(IUserService userService, IMapper mapper, UserManager<User> userManager, IEmailSender emailSender)
        {
            _userService = userService;
            _mapper = mapper;
            _userManager = userManager;
            _emailSender = emailSender;
        }

        [HttpPost]
        public async Task<IActionResult> CreateUser([FromBody] UserDto userdto)
        {
            var User = _mapper.Map<User>(userdto);
            var AddUserResponse = await _userService.AddUser(User, userdto.Password);
            if (AddUserResponse)
            {
                var token = await _userManager.GenerateEmailConfirmationTokenAsync(User);
                var confirmationLink = $"http://localhost:4200/Confirmation?token={token}";
                confirmationLink = System.Net.WebUtility.UrlEncode(confirmationLink);
                var message = new Message(new string[] { User.Email }, "Confirmation email link", $"Cuenta: {User.UserName} Link de verificacion: {confirmationLink}");
                _emailSender.SendEmail(message);
            }

            return Ok();
        }


        [HttpGet]
        public async Task<bool> ConfirmEmail([FromQuery]string token, [FromQuery]string email)
        {
            var user = await _userManager.FindByEmailAsync(email);
            if (user == null)
                return false;

            var result = await _userManager.ConfirmEmailAsync(user, token);
            return result.Succeeded;
        }


        [HttpGet]
        public async Task<List<User>> GetUsers()
        {
            return await _userService.GetUsers();
        }

    }
}
