﻿using System;
using System.Net;
using System.Threading.Tasks;
using CrossCutting.Errors;
using Microsoft.ApplicationInsights;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace Cliente_Dinamico_Api
{
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate _next;

        public ErrorHandlingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private async Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            var telemetry = new TelemetryClient();
            telemetry.TrackException(exception);

            var code = exception is HttpException ? ((HttpException)exception).CodeHttp : HttpStatusCode.InternalServerError;
            var result = JsonConvert.SerializeObject(new { exception.Message });

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)code;
            await context.Response.WriteAsync(result);
        }
    }
}
