﻿using AutoMapper;
using Cliente_Dinamico_Api.Models.Input;
using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cliente_Dinamico_Api.Models.Mapping
{
    public class InputMapping : Profile
    {
        public InputMapping()
        {
            CreateMap<UserDto, User>();
        }
    }
}
