﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace CrossCutting.Errors
{
    public abstract class HttpException : Exception
    {
        public abstract HttpStatusCode CodeHttp { get; }

        public HttpException() : base()
        {

        }

        public HttpException(string message) : base(message)
        {

        }
    }
}
