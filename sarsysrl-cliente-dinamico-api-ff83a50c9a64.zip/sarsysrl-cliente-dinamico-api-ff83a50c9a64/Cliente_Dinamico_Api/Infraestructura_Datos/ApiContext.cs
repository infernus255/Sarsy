﻿using System;
using System.Collections.Generic;
using System.Text;
using Entidades;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Infraestructura_Datos
{
    public class ApiContext: IdentityDbContext
    {

        public ApiContext(DbContextOptions<ApiContext> options) : base(options)
        {
        }
        public DbSet<User> User { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
            .Property(f => f.idUser).Metadata.SetAfterSaveBehavior(Microsoft.EntityFrameworkCore.Metadata.PropertySaveBehavior.Ignore);

            modelBuilder.Entity<User>()
            .Property(f => f.idUser)
            .IsRequired()
            .ValueGeneratedOnAdd();


            base.OnModelCreating(modelBuilder);
        }

    }
}
