﻿using System;

namespace Infraestructura_Datos
{
    public static class DbInitializer
    {
        public static void Initialize(ApiContext context)
        {

        }
    }
}
