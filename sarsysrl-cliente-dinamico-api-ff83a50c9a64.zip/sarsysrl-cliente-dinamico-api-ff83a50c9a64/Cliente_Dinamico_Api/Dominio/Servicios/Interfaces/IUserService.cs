﻿using Entidades;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Servicios.Interfaces
{
    public interface IUserService
    {
        Task<bool> AddUser(User user, string password);
        Task<List<User>> GetUsers();

    }
}
