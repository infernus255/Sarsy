﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Servicios.Interfaces
{
    public interface IAuthService
    {
        public Task<string> LoginAsync(string Email, string password);

    }
}
