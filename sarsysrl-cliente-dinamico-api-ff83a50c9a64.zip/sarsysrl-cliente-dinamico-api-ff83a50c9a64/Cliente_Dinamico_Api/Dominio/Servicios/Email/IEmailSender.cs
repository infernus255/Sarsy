﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Servicios.Email
{
    public interface IEmailSender
    {
        void SendEmail(Message message);
    }
}
