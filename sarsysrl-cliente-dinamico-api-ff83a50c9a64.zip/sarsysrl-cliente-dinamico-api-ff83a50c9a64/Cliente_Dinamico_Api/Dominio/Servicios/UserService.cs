﻿using System;
using System.Threading.Tasks;
using Entidades;
using Servicios.Interfaces;
using Infraestructura_Datos;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using System.Linq;
using System.Collections.Generic;

namespace Servicios
{
    public class UserService : IUserService
    {
        private readonly IConfiguration _config;
        private readonly UserManager<User> _userManager;
        private readonly ApiContext _context;

        public UserService(IConfiguration configuration, UserManager<User> userManager, ApiContext apiContext)
        {
            _config = configuration;
            _userManager = userManager;
            _context = apiContext;
        }


        public async Task<bool> AddUser(User user, string password)
        {
            user.UserName = user.Name;
            var result = await _userManager.CreateAsync(user, password);
            return result.Succeeded;
        }

        public async Task<List<User>> GetUsers()
        {
            var Users = _context.User.ToList();
            return Users;
        }

    }
}
