﻿using System;
using System.Threading.Tasks;
using Entidades;
using Servicios.Interfaces;
using Infraestructura_Datos;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using System.Linq;
using System.Collections.Generic;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using CrossCutting.Errors;

namespace Servicios
{
    public class AuthService : IAuthService
    {
        private readonly IConfiguration _config;
        private readonly UserManager<User> _userManager;
        private readonly ApiContext _context;
        private readonly SignInManager<User> _signInManager;

        public AuthService(IConfiguration configuration, UserManager<User> userManager
                            , ApiContext apiContext, SignInManager<User> signInManager)
        {
            _config = configuration;
            _userManager = userManager;
            _context = apiContext;
            _signInManager = signInManager;
        }

        public async Task<string> LoginAsync(string UserName, string password)
        {
            var result = await _signInManager.PasswordSignInAsync(UserName, password, false, false);
            if (!result.Succeeded) throw new  BadRequestException("Usuario o contraseña invalidos");

            var appUser = _userManager.Users.SingleOrDefault(r => r.UserName == UserName);
            return GenerateJwtToken(UserName, appUser);
        }
        private string GenerateJwtToken(string email, User user)
        {
        //    var rolId = _context.UserRoles.Where(x => x.UserId == user.Id).Select(x => x.RoleId).FirstOrDefault();
        //    var rol = _context.Roles.Where(x => x.Id == rolId).Select(x => x.Name).FirstOrDefault();

            var claims = new List<Claim>
            {
                new Claim(JwtRegisteredClaimNames.Sub, email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.NameIdentifier, user.Id),
        //        new Claim(ClaimTypes.Role, rol)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var expires = DateTime.Now.AddDays(Convert.ToDouble(_config["Jwt:ExpireDays"]));

            var token = new JwtSecurityToken(
                _config["Jwt:Issuer"],
                _config["Jwt:Issuer"],
                claims,
                expires: expires,
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
