﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Infrastructure.Models
{
    public class UserActivity
    {
        public string IsActive { get; set; }
        public string ProjectId { get; set; }
        public string TaskId { get; set; }
        public string ProjectName { get; set; }
        public string TaskName { get; set; }
        public string Start_Date { get; set; }
        public string ElapsedTime_Seconds { get; set; }
        public string UserType { get; set; }
        public string Message { get; set; }
    }

    public class UserSearch
    {
        public string UserId { get; set; }
        public string User { get; set; }
    }

    
}
