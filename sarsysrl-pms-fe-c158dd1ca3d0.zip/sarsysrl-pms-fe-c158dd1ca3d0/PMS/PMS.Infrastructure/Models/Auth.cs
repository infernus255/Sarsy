﻿using System;

namespace PMS.Models.Models
{
    public class AuthRequest
    {
        public string User { get; set; }
        public string Password { get; set; }
    }

    public class UserInfo
    {
        public string User { get; set; }
        public string TOKEN { get; set; }
    }

    public class UserActivity
    {
        public string IsActive { get; set; }
        public string ProjectId { get; set; }
        public string TaskId { get; set; }
        public string IsExtra { get; set; }
        public string ProjectName { get; set; }
        public string TaskName { get; set; }
        public string Start_Date { get; set; }
        public string ElapsedTime_Seconds { get; set; }
        public string UserType { get; set; }
        public string Message { get; set; }
    }

    public class UserActivityResponse
    {
        public string Status { get; set; }
        public UserActivity userActivity { get; set; }
    }

    public class AuthTOKENResponse
    {
        public string Status { get; set; }
        public string Description { get; set; }
    }

    public class AuthResponse
    {
        public string Status { get; set; }
        public string Description { get; set; }
        public string Profile { get; set; }
        public string Name { get; set; }
        public string Title { get; set; }
        public string TOKEN { get; set; }
    }

    public class UserSearch
    {
        public string UserId { get; set; }
        public string User { get; set; }
    }

    public class UserExit
    {
        public string Status { get; set; }
        public string Hora { get; set; }
    }

    public class UserDates
    {
        public string Name { get; set; }
        public string User { get; set; }
        public DateTime Date { get; set; }
    }
}
