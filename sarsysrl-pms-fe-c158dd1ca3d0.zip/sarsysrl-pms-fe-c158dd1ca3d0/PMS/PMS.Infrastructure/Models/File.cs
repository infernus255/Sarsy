﻿namespace PMS.Infrastructure.Models
{
    public class File
    {
        public string Content { get; set; }
        public string Name { get; set; }
        public string Extension { get; set; }
    }
}
