﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Hosting;

namespace PMS.Infrastructure.Models
{
    class Log
    {
        public static void LogErrorMessage(string mensaje)
        {
            if (Directory.Exists("~//Logs//log.txt"))
            {
                //File file = Directory.Get
            }
            else
            {
                Directory.CreateDirectory("~//Logs//log.txt");
            }

        }
    }
}
