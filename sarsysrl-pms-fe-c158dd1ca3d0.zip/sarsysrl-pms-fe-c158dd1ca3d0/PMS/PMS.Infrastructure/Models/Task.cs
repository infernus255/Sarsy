﻿using PMS.Infrastructure.Models;
using System;
using System.Collections.Generic;

namespace PMS.Models.Models
{
    public class TaskRequest
    {
        public int Id { get; set; }
        public int IsExtra { get; set; }
    }

    public class TaskResponse
    {
        public string Status { get; set; }
        public List<TaskItem> TaskItems { get; set; }
    }

    public class TaskItem
    {
        public int Id { get; set; }
        public string Task { get; set; }
    }

    public class TaskResult
    {
        public string result { get; set; }
    }
    public class NewTask
    {
        public string UserCreator { get; set; }
        public string Usertask { get; set; }
        public string TaskName { get; set; }
        public int Projectid { get; set; }
    }

    public class Observation
    {
        public int Proyect { get; set; }
        public string ProyectName { get; set; }
        public int Task { get; set; }
        public string TaskName { get; set; }
        public string Header { get; set; }
        public string observation { get; set; }
        public File File { get; set; }
    }

    public class NewToDo
    {
        public string Descripcion { get; set; }
        public string User { get; set; }
        public int IdToDo { get; set; }
    }

    public class NewToDoTask
    {
        public string Descripcion { get; set; }
        public string User { get; set; }
        public int IdProject { get; set; }
        public int IdToDo { get; set; }
    }
    public class ToDoResponse
    {
        public string Status { get; set; }
        public List<NewToDo> ToDoItems { get; set; }
    }


    public class Download
    {
        public string ObsId { get; set; }
        public string Autor { get; set; }
        public string Header { get; set; }
        public string Observation { get; set; }
        public DateTime DateUpload { get; set; }
        public string File { get; set; }
    }


    public class ObsInfo
    {

        public string Status { get; set; }
        public List<Download> ObsItems { get; set; }

    }

    public class DownloadFile
    {
        public string Status { get; set; }
        public string Path { get; set; }
        public File file { get; set; }
    }


    public class TaskSearch
    {
        public string Status { get; set; }
        public List<SearchItem> TaskItems { get; set; }
    }


    public class SearchItem
    {
        public int Taskid { get; set; }
        public int Projectid { get; set; }
        public string TaskName { get; set; }
        public string ProjectName { get; set; }
    }

    public class TaskHelper
    {
        public string User { get; set; }
        public string Password { get; set; }

    }



}