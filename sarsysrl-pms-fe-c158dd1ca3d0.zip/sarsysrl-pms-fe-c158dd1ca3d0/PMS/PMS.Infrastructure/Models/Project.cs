﻿using System.Collections.Generic;

namespace PMS.Models.Models
{

    public class ProjectsResponse
    {
        public string Status { get; set; }
        public List<ProjectItem> ProjectItems { get; set; }
    }

    public class ProjectItem
    {
        public int Id { get; set; }
        public string Project { get; set; }
    }

    public class DownloadAll
    {
        public string ObsId { get; set; }
        public string Empresa { get; set; }
        public string Proyecto { get; set; }
        public string Tarea { get; set; }
        public string Autor { get; set; }
        public string Header { get; set; }
        public string Observation { get; set; }
        public string File { get; set; }
    }


    public class AllObsInfo
    {

        public string Status { get; set; }
        public List<DownloadAll> ObsItems { get; set; }

    }



}