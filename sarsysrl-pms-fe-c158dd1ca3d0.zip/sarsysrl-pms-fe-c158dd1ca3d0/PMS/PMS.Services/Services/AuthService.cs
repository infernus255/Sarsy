﻿using Newtonsoft.Json;
using PMS.Models.Models;
using PMS.Services.Helpers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Services.Services
{
    public class AuthService : RestBase
    {
        public AuthService() : base("auth") { }

        public async Task<AuthResponse> LoginAsync(AuthRequest user)
        {
            AuthResponse authResponse = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "login")
            {
                Content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json")
            };
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                authResponse = JsonConvert.DeserializeObject<AuthResponse>(content);
            }
            return authResponse;
        }

        public async Task<bool> LogoutAsync(UserInfo user)
        {
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "logout");
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            return response.IsSuccessStatusCode;
        }


    }
}
