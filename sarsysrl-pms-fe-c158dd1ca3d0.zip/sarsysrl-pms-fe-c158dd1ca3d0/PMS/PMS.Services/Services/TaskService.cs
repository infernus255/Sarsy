﻿using Newtonsoft.Json;
using PMS.Models.Models;
using PMS.Services.Helpers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Web;
using System.Net.Http.Headers;
using System.Web.UI.WebControls;
using System.IO;

namespace PMS.Services.Services
{
    public class TaskService : RestBase
    {

       
        public TaskService() : base("task") { }

        public async Task<TaskResponse> ListTaskAsync(UserInfo user, int projectId)
        {
            TaskResponse taskResponse = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, $"list/{projectId}");
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                taskResponse = JsonConvert.DeserializeObject<TaskResponse>(content);
            }
            return taskResponse;
        }

        public async Task<bool> StartTaskAsync(UserInfo user, TaskRequest taskRequest)
        {
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "start")
            {
                Content = new StringContent(JsonConvert.SerializeObject(taskRequest), Encoding.UTF8, "application/json")
            };
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            return response.IsSuccessStatusCode;
        }


        public async Task<bool> FinishCurrentAsync(UserInfo user, int taskid=0)
        {
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "FinishCurrent") { };
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> FinishTaskNotPlay(UserInfo user, int taskid = 0)
        {
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "FinishTaskNotPlay") { };
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            request.Headers.Add("TaskID", taskid.ToString());
            var response = await client.SendAsync(request);
            return response.IsSuccessStatusCode;
        }



        public async Task<bool> StopTaskAsync(UserInfo user, TaskRequest taskRequest)
        {
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "stop")
            {
                Content = new StringContent(JsonConvert.SerializeObject(taskRequest), Encoding.UTF8, "application/json")
            };
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            return response.IsSuccessStatusCode;
        }


        public async Task<TaskResult> AddTaskAsync(UserInfo user, NewTask newTask)
        {
            TaskResult taskresult = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "Add")
            {
                Content = new StringContent(JsonConvert.SerializeObject(newTask), Encoding.UTF8, "application/json")
            };
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                taskresult = JsonConvert.DeserializeObject<TaskResult>(content);

            }
            return taskresult;
        }

        public async Task<bool> FinishToDoAsync(UserInfo user,NewToDo id)
        {
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "FinishToDo") {

                Content = new StringContent(JsonConvert.SerializeObject(id), Encoding.UTF8, "application/json")
            };
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            return response.IsSuccessStatusCode;
        }

        public async Task<ToDoResponse> ListToDoAsync(UserInfo user)
        {
            ToDoResponse taskResponse = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "listToDo");
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                taskResponse = JsonConvert.DeserializeObject<ToDoResponse>(content);
            }

            return taskResponse;
        }

        public async Task<TaskResult> AddToDoAsync(UserInfo user, NewToDo newTask)
        {
            TaskResult taskresult = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "AddToDo")
            {
                Content = new StringContent(JsonConvert.SerializeObject(newTask), Encoding.UTF8, "application/json")
            };
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                taskresult = JsonConvert.DeserializeObject<TaskResult>(content);

            }
            return taskresult;
        }


        public async Task<TaskResult> AddTaskFromTodoAsync(UserInfo user, NewToDoTask newTask)
        {
            TaskResult taskresult = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "AddFromToDo")
            {
                Content = new StringContent(JsonConvert.SerializeObject(newTask), Encoding.UTF8, "application/json")
            };
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                taskresult = JsonConvert.DeserializeObject<TaskResult>(content);

            }
            return taskresult;
        }




        public async Task<TaskResult> AddObsAsync(Observation observation, UserInfo user)
        {
            TaskResult result = new TaskResult();

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "AddObs")
            {
                Content = new StringContent(JsonConvert.SerializeObject(observation), Encoding.UTF8, "application/json")
            };
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                result = JsonConvert.DeserializeObject<TaskResult>(content);


            }
            return result;
        }

        public async Task<ObsInfo> ShowObsAsync(UserInfo user, int taskid)
        {
            ObsInfo projects = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "GetObs");
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            request.Headers.Add("TaskID", taskid.ToString());
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                projects = JsonConvert.DeserializeObject<ObsInfo>(content);
                
                
            }
            return projects;
        }










        public async Task<DownloadFile> DownloadFileAsync(UserInfo user, int ObsId)
        {
            DownloadFile projects = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "GetFile");
             request.Headers.Add("User", user.User);
             request.Headers.Add("Token", user.TOKEN);
             request.Headers.Add("ObsId", ObsId.ToString());
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                projects = JsonConvert.DeserializeObject<DownloadFile>(content);


            }
            return projects;

        }



        public async Task<TaskSearch> ListTaskSearchAsync(UserInfo user, string User)
        {
            TaskSearch taskResponse = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "SearchTask");
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            request.Headers.Add("UserID", User);
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                taskResponse = JsonConvert.DeserializeObject<TaskSearch>(content);
            }
            return taskResponse;
        }

        public async Task<bool> TaskHelpAsync(UserInfo user, TaskHelper Helper)
        {
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "TaskHelp")
            {
                Content = new StringContent(JsonConvert.SerializeObject(Helper), Encoding.UTF8, "application/json")
            };
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            return response.IsSuccessStatusCode;
        }

    }
}

