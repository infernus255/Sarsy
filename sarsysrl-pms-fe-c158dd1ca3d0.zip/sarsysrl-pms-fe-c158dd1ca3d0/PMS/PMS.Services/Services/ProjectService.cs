﻿using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PMS.Models.Models;
using PMS.Services.Helpers;

namespace PMS.Services.Services
{
    public class ProjectService : RestBase
    {
        public ProjectService() : base("project") { }

        public async Task<ProjectsResponse> ShowProjectsAsync(UserInfo user)
        {
            ProjectsResponse projects = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "show");
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                projects = JsonConvert.DeserializeObject<ProjectsResponse>(content);
            }
            return projects;
        }

        public async Task<AllObsInfo> ShowAllObsAsync(UserInfo user)
        {
            AllObsInfo projects = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "GetObs");
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                projects = JsonConvert.DeserializeObject<AllObsInfo>(content);


            }
            return projects;
        }


    }
}
