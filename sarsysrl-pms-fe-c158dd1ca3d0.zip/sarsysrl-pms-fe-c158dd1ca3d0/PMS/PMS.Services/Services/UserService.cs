﻿using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PMS.Models.Models;
using PMS.Services.Helpers;
using System.Collections.Generic;
using System.Text;
using System;
using System.Web;
using System.Net.Http.Headers;
using System.Web.UI.WebControls;
using System.IO;

namespace PMS.Services.Services
{
    public class UserService : RestBase
    {
            public UserService() : base("User") { }
        
            public async Task<UserActivity>     GetUserStatusAsync(UserInfo user)
            {
            UserActivity useractivity = null;
                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "Activity");
                request.Headers.Add("User", user.User);
                request.Headers.Add("Token", user.TOKEN);
                var response = await client.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    var userActivityResponse = JsonConvert.DeserializeObject<UserActivityResponse>(content);
                    useractivity = userActivityResponse.userActivity;
                }
                return useractivity;
            }

        public async Task<List<Models.Models.UserSearch>> ListUsersAsync(UserInfo user, string User)
        {
            List<UserSearch> UserResponse = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "ListUser");
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            request.Headers.Add("Username", User);
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                UserResponse = JsonConvert.DeserializeObject<List<UserSearch>>(content);
            }
            return UserResponse;
        }


        public async Task<List<Models.Models.UserSearch>> ListUsersAllAsync(UserInfo user, string User)
        {
            List<UserSearch> UserResponse = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "ListUserAll");
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            request.Headers.Add("Username", User);
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                UserResponse = JsonConvert.DeserializeObject<List<UserSearch>>(content);
            }
            return UserResponse;
        }



        public async Task<List<UserDates>> ListUsersDates(UserInfo user)
        {
            List<UserDates> UserResponse = null;
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "ListUserDates");
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
               
                var content = await response.Content.ReadAsStringAsync();
                UserResponse = JsonConvert.DeserializeObject<List<UserDates>>(content);
                if (UserResponse.Count < 1)
                {
                    UserResponse = null;
                    return UserResponse;
                }

                   
                
            }
            return UserResponse;
           
        }




        public async Task<string> CorrectDay(UserInfo user, string Hora)
        {
            

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "CorrectHour") { };
            request.Headers.Add("User", user.User);
            request.Headers.Add("Token", user.TOKEN);
            request.Headers.Add("Hora", Hora);
            var response = await client.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();
            var mensaje=JsonConvert.DeserializeObject<string>(content);
            return Convert.ToString(mensaje);
            
        }




    }

    
}
