﻿using System;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;

namespace PMS.Services.Helpers
{
    public class RestBase
    {
        protected HttpClient client;

        public RestBase(string endpoint = "", bool encodingTypeIsJson = true)
        {
            client = new HttpClient();

            //Add common endpoint to all routes
            var url = ConfigurationManager.AppSettings["PMS_API_URL_BASE"] + (string.IsNullOrEmpty(endpoint) ? "" : $"{endpoint}/");

            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(encodingTypeIsJson ? "application/json" : "application/x-www-form-urlencoded"));
        }
    }
}
