﻿using PMS.Models.Models;
using PMS.Services.Helpers;
using PMS.Services.Services;
using System;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI.WebControls;


namespace PMS.Frontend
{
    public partial class Tasks : System.Web.UI.Page
    {
            

        private TaskService _taskService = new TaskService();

        public TaskRequest taskRequest = new TaskRequest();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var projectId = Request.QueryString["Id"];
                if (string.IsNullOrEmpty(projectId))
                {
                    Response.Redirect("Projects.aspx");
                }

                var cookie = Request.Cookies["session"];
               

                var userInfo = new UserInfo()
                {
                    User = cookie.Values["User"],
                    TOKEN = cookie.Values["Token"]
                };

                getTasks(userInfo, int.Parse(projectId));
            }
        }



        public async Task StartTask(int a, int b)
        {
            // Response.Write("Clickeaste");
            var cookie = Request.Cookies["session"];

            var userInfo = new UserInfo()
            {
                User = cookie.Values["User"],
                TOKEN = cookie.Values["Token"]
            };

            TaskRequest taskRequest = new TaskRequest()
            {
               Id = a,
            IsExtra = b //valores posibles: [0,1]
        };
           


            await _taskService.StartTaskAsync(userInfo, taskRequest);

        }
        

        private async void getTasks(UserInfo userInfo, int projectId)
        {
            var response = await _taskService.ListTaskAsync(userInfo, projectId);

            if (!response.IsNull())
            {
                tasks.DataSource = response.TaskItems;
                tasks.DataBind();
            }
        }

        protected async void tasks_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
           await StartTask(int.Parse(e.CommandArgument.ToString()), int.Parse(e.CommandName.ToString()));
            
        }


         

    }
}