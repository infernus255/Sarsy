﻿using PMS.Models.Models;
using PMS.Services.Helpers;
using PMS.Services.Services;
using System;

namespace PMS.Frontend
{
    public partial class Projects1 : System.Web.UI.Page
    {
        private ProjectService _projectService = new ProjectService();
      
        protected async void Page_Load(object sender, EventArgs e)
        {
            var cookie = Request.Cookies["session"];
            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };

            var response = await _projectService.ShowProjectsAsync(userInfo);

            if (!response.IsNull())
            {
                projects.DataSource = response.ProjectItems;
                projects.DataBind();
            }
        }


        protected void projects_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "tasks")
            {
                Response.Redirect($"Tasks.aspx?Id={e.CommandArgument}");
            }
        }
    }
}