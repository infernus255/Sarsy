﻿using PMS.Models.Models;
using PMS.Services.Services;
using System;

namespace PMS.Frontend
{
    public partial class Projects_Stopped : System.Web.UI.Page
    {
        private TaskService _taskService = new TaskService();

        private UserService _userService = new UserService();


        private UserActivity _userActivity = new UserActivity();


        protected async void Page_Load(object sender, EventArgs e)
        {

            var cookie = Request.Cookies["session"];
            if (cookie == null)
            {
                Response.Redirect("Login.aspx", false);
            }
            else
            {
                var userInfo = new UserInfo()
                {
                    User = cookie.Values["user"],
                    TOKEN = cookie.Values["token"]
                };

                var userresponse = await _userService.GetUserStatusAsync(userInfo);
                try
                {
                    switch (userresponse.IsActive)
                    {
                        case "0": { break; }
                        case "1": { Response.Redirect("Project_X_Task.aspx", false); } break;
                        case "3": { Response.Redirect("Project_X_Task.aspx", false); } break;
                        default: { Response.Redirect("Home.aspx", false); } break;
                    }
                }
                catch(Exception)
                {
                    Response.Redirect("ErrorPage.aspx", false);
                }
            }
           
        }

        protected void projects_ServerClick(object sender, EventArgs e)
        {
            StartDay();
            Response.Redirect("Project_X_Task.aspx", false);
        }

        private async void StartDay()
        {
            var cookie = Request.Cookies["session"];
            if (cookie != null)
            {
                var userInfo = new UserInfo()
                {
                    User = cookie.Values["user"],
                    TOKEN = cookie.Values["token"]
                };
                TaskRequest taskRequest = new TaskRequest()
                {
                    Id = 0,
                    IsExtra = 0 //valores posibles: [0,1]
                };
                await _taskService.StartTaskAsync(userInfo, new TaskRequest());
            }
            else
            {
                Response.Redirect("Login.aspx", false);
            }

        }
    }
}





