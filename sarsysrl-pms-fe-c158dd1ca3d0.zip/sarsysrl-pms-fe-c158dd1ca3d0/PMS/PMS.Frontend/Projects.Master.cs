﻿using PMS.Models.Models;
using PMS.Services.Helpers;
using PMS.Services.Services;
using System;
using System.Web;

namespace PMS.Frontend
{
    public partial class Projects : System.Web.UI.MasterPage
    {
        private TaskService _taskService = new TaskService();
        protected void Page_Load(object sender, EventArgs e)
        {
            var cookie = Request.Cookies["session"];
            if (cookie.IsNull())
            {
                Response.Redirect("Login.aspx");
            }

            user.InnerHtml = $"Bienvenido {cookie.Values["name"]}";
            level.InnerHtml = $"Nivel: {cookie.Values["title"]}";

            var url = HttpContext.Current.Request.Url.AbsolutePath;
            if (url.IndexOf("Home") != -1)
            {
                stop.Visible = false;
            }
        }

        protected void logout_ServerClick(object sender, EventArgs e)
        {
            try
            {
                var cookie = Request.Cookies["session"];
                cookie.Expires = DateTime.Now.AddYears(-2);
                Response.Cookies.Add(cookie);
                Response.Redirect("Login.aspx", false);
            }
           catch(Exception ex)
            {
                Response.Write(ex.Message);
            }

        }

        protected async void stop_ServerClick(object sender, EventArgs e)
        {

                var cookie = Request.Cookies["session"];
                var userInfo = new UserInfo()
                {
                    User = cookie.Values["user"],
                    TOKEN = cookie.Values["token"]
                };
                var request = new TaskRequest()
                {
                    Id= -1,
                    IsExtra=-1
                };
                await _taskService.StopTaskAsync(userInfo, request );

                Response.Redirect("Home.aspx", false);


        }

        public void volver(object source, EventArgs e)
        {
            var cookie = Request.Cookies["session"];
            Response.Redirect("Project_X_Task.aspx",false);
        }

        //public bool btnBackVisible
        //{
        //    get { return btnBack.Visible; }
        //    set { btnBack.Visible = value; }
        //}

        public string enablerefresh
        {
            
            get { return Refresh.HRef; }
            set { Refresh.HRef = value; }
        }
    }
}