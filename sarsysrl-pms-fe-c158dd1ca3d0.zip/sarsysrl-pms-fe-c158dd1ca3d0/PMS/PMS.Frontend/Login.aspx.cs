﻿using PMS.Models.Models;
using PMS.Services.Helpers;
using PMS.Services.Services;
using System.Web;
using System;

namespace PMS.Frontend
{
    public partial class Login : System.Web.UI.Page
    {
        private AuthService _authService = new AuthService();

        private UserActivity _userActivity = new UserActivity();

        protected void Page_Load(object sender, EventArgs e)
        {
            var cookie = Request.Cookies["session"];
            var cookieLastPanel = Request.Cookies["lastpanel"];
            if (cookie != null && cookieLastPanel != null)
            {
                Response.Redirect("Project_X_Task.aspx", false);
            }
        }

        protected async void btnLogin_ServerClick(object sender, EventArgs e)
        {
            var reqUser = new AuthRequest()
            {
                User = user.Value,
                Password = password.Value
            };           
            var response = await _authService.LoginAsync(reqUser);

            if (!response.IsNull())
            {                
                var cookie = new HttpCookie("session");
                cookie.Values.Add("token", response.TOKEN);
                cookie.Values.Add("user", user.Value);
                cookie.Values.Add("name", response.Name); 
                cookie.Values.Add("title", response.Title);
                cookie.Values.Add("startDay", response.Title);
                cookie.Expires = DateTime.Now.AddYears(2);
                Response.Cookies.Add(cookie);

                var LastPanel = new HttpCookie("lastpanel");
                LastPanel.Values.Add("Panel", "Project");
                LastPanel.Expires = DateTime.Now.AddYears(2);
                Response.Cookies.Add(LastPanel);

                Response.Redirect("Home.aspx");

            }
            //else{//MOSTRAR ERROR LOGIN}
        }
    }
}