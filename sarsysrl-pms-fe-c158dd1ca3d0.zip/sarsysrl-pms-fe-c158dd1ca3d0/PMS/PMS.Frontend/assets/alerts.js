﻿//POP-UP

// js function to display alert
function showDeleteConfirmation() {
    return new Promise(resolve => {
        Swal.fire({
            title: '¿Está seguro que desea terminar el dia?',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Aceptar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.value) {
                resolve(true);
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                resolve(false);
            }
        });
    });
}

// js function to display alert logout
function showDeleteConfirmationlogout() {
    return new Promise(resolve => {
        Swal.fire({
            title: '¿Está seguro que desea cerrar sesion?',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Aceptar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.value) {
                resolve(true);
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                resolve(false);
            }
        });
    });
}

//Confirmacion para agregar tarea
function showDeleteConfirmationaddtask() {
    return new Promise(resolve => {
        Swal.fire({
            title: '¿Está seguro que desea agregar esta tarea?',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Aceptar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.value) {
                resolve(true);
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                resolve(false);
            }
        });
    });
}

//Confirmacion para finalizar tarea
function showDeleteConfirmationtask() {
    return new Promise(resolve => {
        Swal.fire({
            title: '¿Está seguro que desea finalizar la tarea?',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Aceptar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.value) {
                resolve(true);
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                resolve(false);
            }
        });
    });
}

//Confirmacion para cargar hora
function showDeleteConfirmationHour() {
    return new Promise(resolve => {
        Swal.fire({
            title: '¿Está seguro que desea cargar esta hora?',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Aceptar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.value) {
                resolve(true);
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                resolve(false);
            }
        });
    });
}

//Confirmacion para cargar horario
function showDeleteConfirmationConfirmHour() {
    return new Promise(resolve => {
        Swal.fire({
            title: '¿Está seguro que desea cargar este horario?',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Aceptar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.value) {
                resolve(true);
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                resolve(false);
            }
        });
    });
}

//Confirmacion para subir observacion
function showDeleteConfirmationaddobs() {
    return new Promise(resolve => {
        Swal.fire({
            title: '¿Está seguro que desea subir esta observacion?',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Aceptar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.value) {
                resolve(true);
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                resolve(false);
            }
        });
    });
}

//Alerta por cabecera y observacion vacios
function showWarningObservation() {
    return new Promise(resolve => {
        Swal.fire({
            title: 'ADVERTENCIA: ERROR AL CARGAR OBSERVACIONES, CABECERA Y OBSERVACION OBLIGATORIOS ',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'Aceptar'
        }).then((result) => {
            if (result.value) {
                resolve(true);
                document.getElementById('formularioAgregarObs').style.display = 'initial'
                document.getElementById('btnAgregarDoc').style.display = 'none'

            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                resolve(false);
            }
        });
    });
}

//Confirmacion para iniciar horas extras
function showDeleteConfirmationextra() {
    return new Promise(resolve => {
        Swal.fire({
            title: '¿Está seguro que desea comenzar horas extras?',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Aceptar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.value) {
                resolve(true);
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                resolve(false);
            }
        });
    });
}