﻿// js function to postpone callback
async function postponePostback(ctl, event, method, isPromise) {
    // Store href attribute of link ctl (this) button
    var defaultAction = $(ctl).prop("href");
    // Cancel default link behaviour
    event.preventDefault();
    if (isPromise) {
        if (await method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
    else {
        if (method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
}

// js function to postpone callback logout
async function postponePostbacklogout(ctl, event, method, isPromise) {
    // Store href attribute of link ctl (this) button
    var defaultAction = $(ctl).prop("href");
    // Cancel default link behaviour
    event.preventDefault();
    if (isPromise) {
        if (await method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
    else {
        if (method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
}

async function postponePostbackaddtask(ctl, event, method, isPromise) {
    // Store href attribute of link ctl (this) button
    var defaultAction = $(ctl).prop("href");
    // Cancel default link behaviour
    event.preventDefault();
    if (isPromise) {
        if (await method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
    else {
        if (method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
}

// js function to postpone callback horasextra
async function postponePostbackextra(ctl, event, method, isPromise) {
    // Store href attribute of link ctl (this) button
    var defaultAction = $(ctl).prop("href");
    // Cancel default link behaviour
    event.preventDefault();
    if (isPromise) {
        if (await method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
    else {
        if (method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
}

// js function to postpone callback
async function postponePostbackaddobs(ctl, event, method, isPromise) {
    // Store href attribute of link ctl (this) button
    var defaultAction = $(ctl).prop("href");
    // Cancel default link behaviour
    event.preventDefault();
    if (isPromise) {
        if (await method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
    else {
        if (method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
}

// js function to postpone callback
async function postponePostbackHour(ctl, event, method, isPromise) {
    // Store href attribute of link ctl (this) button
    var defaultAction = $(ctl).prop("href");
    // Cancel default link behaviour
    event.preventDefault();
    if (isPromise) {
        if (await method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
    else {
        if (method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
}

async function postponePostbackConfirmHour(ctl, event, method, isPromise) {
    // Store href attribute of link ctl (this) button
    var defaultAction = $(ctl).prop("href");
    // Cancel default link behaviour
    event.preventDefault();
    if (isPromise) {
        if (await method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
    else {
        if (method()) {
            // Resume default link action
            window.location.href = defaultAction;
            return true;
        }
        else {
            return false;
        }
    }
}