﻿using PMS.Models.Models;
using PMS.Services.Helpers;
using PMS.Services.Services;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;

namespace PMS.Frontend
{
    public partial class Project_X_Task : System.Web.UI.Page
    {
        private TaskService _taskService = new TaskService();

        private ProjectService _projectService = new ProjectService();

        private UserService _userService = new UserService();

        //string projectName, startTimeSecs;
        string projectName;
        DateTime timeStart;
        int Extra, taskId;
        //int Extra, time, taskId;

        protected async void Page_Load(object sender, EventArgs e)
        {
       

            var cookie = Request.Cookies["session"];

            //Si inicio sesion
            if (cookie == null)
            {
                Response.Redirect("Login.aspx", false);
            }
            else
            {
                var userInfo = new UserInfo()
                {
                    User = cookie.Values["user"],
                    TOKEN = cookie.Values["token"]
                };

                var userresponse = await _userService.GetUserStatusAsync(userInfo);

                try
                {
                    switch (userresponse.IsActive)
                    {
                        case "0": {//Si no inicio el dia
                                Response.Redirect("Home.aspx", false); } break;
                        case "1": {//Si ya inicio el dia

                                hdfProject.Value = userresponse.TaskId.ToString();

                                string nombres = "";
                                string fechas = "";
                                List<UserDates> Cumples = await _userService.ListUsersDates(userInfo);
                                if (Cumples != null)
                                {
                                    if (Cumples.Count == 1)
                                    {
                                        lblCumpleanios.Text = "  " + Cumples[0].Name + " cumple años el " + Cumples[0].Date.Day.ToString() + "/" + Cumples[0].Date.Month.ToString();

                                    }
                                    else
                                    {
                                        for (int x = 0; x < Cumples.Count; x++)
                                        {
                                            if (x != Cumples.Count - 1)
                                            {

                                                nombres = nombres + Cumples[x].Name + ", ";
                                                fechas = fechas + Cumples[x].Date.Day.ToString() + "/" + Cumples[x].Date.Month.ToString() + ", ";
                                            }
                                            else
                                            {
                                                nombres = nombres + Cumples[x].Name;
                                                fechas = fechas + Cumples[x].Date.Day.ToString() + "/" + Cumples[x].Date.Month.ToString();
                                            }

                                            lblCumpleanios.Text = "  " + nombres + " cumplen años el " + fechas;
                                        }

                                    }
                                }

                                StartTime.Value = userresponse.ElapsedTime_Seconds;

                                //Cuando se recarga la pagina
                                if (!IsPostBack)
                                {
                                    divSearchTask.Visible = true;
                                    pnlTareas.Controls.Clear();
                                    projectName = "00";
                                    taskId = 0;
                                    timeStart = DateTime.Now;
                                    Extra = 0;

                                    var projectresponse = await _projectService.ShowProjectsAsync(userInfo);
                                    userresponse = await _userService.GetUserStatusAsync(userInfo);
                                    StartTime.Value = userresponse.ElapsedTime_Seconds;

                                    //Datos para el desplegable "Ver Tareas por Hacer"
                                    var ToDoresponse = await _taskService.ListToDoAsync(userInfo);
                                    if (ToDoresponse != null)
                                    {
                                        rptToDo.DataSource = ToDoresponse.ToDoItems;
                                        rptToDo.DataBind();
                                    }


                                    //Donde se recargan todos los proyectos
                                    if (int.Parse(userresponse.ProjectId) == 0)
                                    {

                                        if (!projectresponse.IsNull())
                                        {
                                            projects.DataSource = projectresponse.ProjectItems;
                                            projects.DataBind();
                                            ProyectosUsuarios.DataSource = projectresponse.ProjectItems;
                                            ProyectosUsuarios.DataBind();
                                        }

                                        hdfProject.Value = "0";

                                        var LastPanel = Request.Cookies["lastpanel"];

                                        if (LastPanel != null)
                                        {

                                            if (LastPanel.Values["panel"] == "Project")
                                            {

                                                if (userresponse.UserType == "2")
                                                {
                                                    lblCumpleanios.Visible = false;
                                                    pnlUsuarios.Visible = true;
                                                    pnlProyectos.Visible = false;
                                                    divSearchTask.Visible = true;
                                                    pnlallobs.Visible = false;
                                                    widnow.Visible = true;

                                                }
                                                else
                                                {
                                                    lblCumpleanios.Visible = true;
                                                    pnlUsuarios.Visible = false;
                                                    pnlProyectos.Visible = true;
                                                    divSearchTask.Visible = true;
                                                    pnlallobs.Visible = false;
                                                    widnow.Visible = true;
                                                }

                                            }
                                            else if (LastPanel.Values["panel"] == "TaskSearch")
                                            {
                                                pnlUsuarios.Visible = false;
                                                pnlProyectos.Visible = false;
                                                pnlallobs.Visible = false;
                                                divSearchTask.Visible = true;
                                                await GetAllUserTask();
                                                pnlSearchTask.Visible = true;
                                                widnow.Visible = true;
                                            }
                                            else
                                            {
                                                pnlallobs.Visible = true;
                                                pnlUsuarios.Visible = false;
                                                pnlProyectos.Visible = false;
                                                divSearchTask.Visible = true;
                                                await GetAllObservations();
                                                pnlSearchTask.Visible = false;
                                                widnow.Visible = true;
                                            }
                                        }
                                        pnlTareaActiva.Visible = false;
                                        pnlTareas.Visible = false;
                                        ((Projects)Master).enablerefresh = "#";
                                        divnewtask.Visible = false;
                                        divObservaciones.Visible = false;
                                        lblerrorupload.Visible = false;
                                        lblError.Visible = false;
                                        divObservaciones.Visible = false;
                                        divObservaciones.Visible = false;
                                        pnlObservaciones.Visible = false;
                                        divObservaciones.Visible = false;
                                        widnow.Visible = true;

                                    }

                                    else if (int.Parse(userresponse.TaskId) == 0)
                                    {
                                        lblCumpleanios.Visible = false;
                                        var taskresponse = await _taskService.ListTaskAsync(userInfo, int.Parse(userresponse.TaskId));
                                        pnlTareaActiva.Visible = false;
                                        pnlTareas.Visible = true;
                                        pnlProyectos.Visible = false;
                                        pnlallobs.Visible = false;
                                        widnow.Visible = false;
                                        ((Projects)Master).enablerefresh = "#";
                                        lblerrorupload.Visible = false;
                                        lbladdtask.Visible = false;
                                        divObservaciones.Visible = false;
                                        divSearchTask.Visible = false;
                                        pnlSearchTask.Visible = false;

                                        if (userresponse.UserType == "1")
                                        {

                                            divnewtask.Visible = true;
                                            pnlSearchTask.Visible = false;
                                            divSearchTask.Visible = false;

                                        }

                                        if (!taskresponse.IsNull())
                                        {

                                            //ojo puede pinchar si se hacen 2 bind
                                            tasks.DataSource = taskresponse.TaskItems;
                                            tasks.DataBind();

                                        }
                                    }

                                    else
                                    {
                                        if (lblError.Visible == false)
                                        {
                                            hdfAlerta.Value = "";
                                            hdfProject.Value = userresponse.TaskId.ToString();
                                            lblCumpleanios.Visible = false;
                                            lblprojectname.Text = userresponse.ProjectName;
                                            lblprojectname.Visible = true;
                                            lbltaskid.Text = userresponse.TaskName;
                                            Extra = int.Parse(userresponse.IsExtra);
                                            pnlTareas.Visible = false;
                                            pnlProyectos.Visible = false;
                                            pnlTareaActiva.Visible = true;
                                            widnow.Visible = true;
                                            pnlObservaciones.Visible = false;
                                            pnlallobs.Visible = false;
                                            divSearchTask.Visible = false;
                                            pnlSearchTask.Visible = false;
                                            divnewtask.Visible = false;
                                            divObservaciones.Visible = true;
                                            lblerrorupload.Visible = false;
                                            lbladdtask.Visible = false;

                                            ((Projects)Master).enablerefresh = "Project_X_Task.aspx";
                                            lbltaskid.Text = userresponse.TaskName.ToString();

                                            if (Extra == 0)
                                            {
                                                lblextra.Text = "Normal";
                                            }
                                            else
                                            {
                                                lblextra.Text = "Extra";
                                            }

                                            lblstarttime.Text = userresponse.Start_Date.ToString();

                                        }
                                        //pnlTareaActiva.Visible = true;
                                        //pnlTareas.Visible = false;
                                        //pnlProyectos.Visible = false;
                                    }


                                }

                            } break;
                        case "3": {//Si terminaste el dia y no finalizaste tarea aparecera un mensaje
                                lblCloseDay.Text = userresponse.Message;
                                pnlProyectos.Visible = false;
                                pnlUsuarios.Visible = false;
                                pnlTareas.Visible = false;
                                pnlTareaActiva.Visible = false;
                                pnlObservaciones.Visible = false;
                                pnlCorregirSalida.Visible = true;
                                divnewtask.Visible = false;
                                divObservaciones.Visible = false;
                                pnlSearchTask.Visible = false;
                                Cronometer.Visible = false;
                                divSearchTask.Visible = false;
                                lblCumpleanios.Visible = false;
                                pnlallobs.Visible = false;
                                divHelping.Visible = false;
                                divnewtodotask.Visible = false;
                                widnow.Visible = false;
                            } break;
                        default: { Response.Redirect("Home.aspx", false); } break;
                    }
                }
                catch (Exception)
                {
                    Response.Redirect("ErrorPage.aspx", false);
                }

            }
        }
        protected async Task StartProyect(int id)
        {

            var cookie = Request.Cookies["session"];
            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };

            lblCumpleanios.Visible = false;
            widnow.Visible = false;
            pnlProyectos.Visible = false;
            pnlUsuarios.Visible = false;
            pnlTareas.Visible = true;
            pnlSearchTask.Visible = false;
            divSearchTask.Visible = false;
            pnlallobs.Visible = false;

            int projectId = id;
            var response = await _taskService.ListTaskAsync(userInfo, projectId);

            if (!response.IsNull())
            {
                tasks.DataSource = response.TaskItems;
                tasks.DataBind();

                divObservaciones.Visible = false;
                lblerrorupload.Visible = false;
                lbladdtask.Visible = false;
                pnlSearchTask.Visible = false;
                divSearchTask.Visible = false;
                //((Projects)Master).btnBackVisible = true;
                ((Projects)Master).enablerefresh = "#";

                var userresponse = await _userService.GetUserStatusAsync(userInfo);
                if (userresponse.UserType == "1")
                {
                    PID.Value = id.ToString();
                    pnlSearchTask.Visible = false;
                    divSearchTask.Visible = false;
                    divnewtask.Visible = true;
                    await GetUsersAll();

                }


                hdfProject.Value = id.ToString();
                hdfProyectIdClicked.Value = id.ToString();
            }

        }

        protected async void projects_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            projectName = e.CommandName.ToString();
            await StartProyect(int.Parse(e.CommandArgument.ToString()));
            ActiveProject.Value = projectName;
            lblprojectname.Text = ActiveProject.Value;
            lblprojectname.Visible = true;
            hdfProject.Value = e.CommandArgument.ToString();
            hdfProyectIdClicked.Value = e.CommandArgument.ToString();
        }


        public async Task StartTask(int a, int b)
        {
            lblCumpleanios.Visible = false;
            // Response.Write("Clickeaste");
            var cookie = Request.Cookies["session"];

            var userInfo = new UserInfo()
            {
                User = cookie.Values["User"],
                TOKEN = cookie.Values["Token"]
            };

            TaskRequest taskRequest = new TaskRequest()
            {
                Id = a,
                IsExtra = b //valores posibles: [0,1]
            };

            taskId = taskRequest.Id;
            Extra = taskRequest.IsExtra;
            timeStart = DateTime.Now;

            if (await _taskService.StartTaskAsync(userInfo, taskRequest) == false)
            {
                lblError.Visible = true;
            }

            var userresponse = await _userService.GetUserStatusAsync(userInfo);
            StartTime.Value = userresponse.ElapsedTime_Seconds;
            divnewtask.Visible = false;
            divObservaciones.Visible = true;
            divSearchTask.Visible = false;
            widnow.Visible = true;
            pnlSearchTask.Visible = false;
            lblerrorupload.Visible = false;
            lbladdtask.Visible = false;
            hdfAlerta.Value = "";
            //((Projects)Master).btnBackVisible = false;
            ((Projects)Master).enablerefresh = "Project_X_Task.aspx";

        }

        protected async void tasks_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (int.Parse(e.CommandName.ToString()) == 2)
            {
                FinishTaskNotPlay(source, e, int.Parse(e.CommandArgument.ToString()));
            }
            else
            {
                await StartTask(int.Parse(e.CommandArgument.ToString()), int.Parse(e.CommandName.ToString()));
                if (lblError.Visible == false)
                {
                    pnlTareas.Visible = false;
                    divSearchTask.Visible = false;
                    pnlSearchTask.Visible = false;
                    rptMostrarObs.Controls.Clear();
                    widnow.Visible = true;
                    pnlTareaActiva.Visible = true;
                    lbltaskid.Text = taskId.ToString();
                    if (Extra == 0)
                    {
                        lblextra.Text = "Normal";
                    }
                    else
                    {
                        lblextra.Text = "Extra";
                    }

                    var cookie = Request.Cookies["session"];
                    var userInfo = new UserInfo()
                    {
                        User = cookie.Values["user"],
                        TOKEN = cookie.Values["token"]
                    };

                    var userresponse = await _userService.GetUserStatusAsync(userInfo);
                    lblstarttime.Text = timeStart.ToString();
                    lbltaskid.Text = userresponse.TaskName;
                }

            }
        }

        
        protected async void stoptask(object source, EventArgs e)
        {
            lbladdtask.Visible = false;
            var cookie = Request.Cookies["session"];
            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };
            var request = new TaskRequest()
            {
                Id = -1,
                IsExtra = -1
            };
            await _taskService.StopTaskAsync(userInfo, request);
            await StartTask(0, 0);

            var projectresponse = await _projectService.ShowProjectsAsync(userInfo);
            if (!projectresponse.IsNull())
            {
                projects.DataSource = projectresponse.ProjectItems;
                projects.DataBind();
            }
            pnlTareas.Controls.Clear();
            lblprojectname.Visible = false;
            pnlTareaActiva.Visible = false;
            pnlObservaciones.Visible = false;
            divObservaciones.Visible = false;
            lblCumpleanios.Visible = true;
            rptMostrarObs.Controls.Clear();
            var userresponse = await _userService.GetUserStatusAsync(userInfo);
            if (userresponse.UserType == "2")
            {
                pnlUsuarios.Visible = true;
                pnlProyectos.Visible = false;
                widnow.Visible = true;
                divSearchTask.Visible = false;
                pnlSearchTask.Visible = false;
                pnlallobs.Visible = false;
            }
            else
            {

                widnow.Visible = true;
                pnlUsuarios.Visible = false;
                pnlProyectos.Visible = true;
                divSearchTask.Visible = true;
                pnlSearchTask.Visible = true;
                pnlallobs.Visible = false;
            }
            hdfAlerta.Value = "";
            lblError.Visible = false;
            Response.Redirect("Project_X_Task.aspx", false);
        }

        protected async void FinishTask(object source, EventArgs e)
        {
            var cookie = Request.Cookies["session"];



            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };

            await _taskService.FinishCurrentAsync(userInfo,taskId);

            var projectresponse = await _projectService.ShowProjectsAsync(userInfo);
            if (!projectresponse.IsNull())
            {
                projects.DataSource = projectresponse.ProjectItems;
                projects.DataBind();
            }
            pnlTareas.Controls.Clear();
            lblprojectname.Visible = false;
            pnlTareaActiva.Visible = false;
            pnlObservaciones.Visible = false;
            lblCumpleanios.Visible = true;
            widnow.Visible = true;
            divObservaciones.Visible = false;
            rptMostrarObs.Controls.Clear();
            var userresponse = await _userService.GetUserStatusAsync(userInfo);
            if (userresponse.UserType == "2")
            {
                pnlUsuarios.Visible = true;
                pnlProyectos.Visible = false;
                divSearchTask.Visible = false;

                widnow.Visible = true;
                pnlSearchTask.Visible = false;
                pnlallobs.Visible = false;
            }
            else
            {
                pnlUsuarios.Visible = false;
                pnlProyectos.Visible = true;

                widnow.Visible = true;
                divSearchTask.Visible = true;
                pnlSearchTask.Visible = true;
                pnlallobs.Visible = false;
            }
            lblError.Visible = false;
            divnewtask.Visible = false;
            divObservaciones.Visible = false;
            lblerrorupload.Visible = false;
            lbladdtask.Visible = false;
            hdfAlerta.Value = "";
            //((Projects)Master).btnBackVisible = false;
            ((Projects)Master).enablerefresh = "#";
            Response.Redirect("project_X_Task.aspx");
        }

        protected async void FinishTaskNotPlay(object source, EventArgs e, int idTarea)
        {
            var cookie = Request.Cookies["session"];



            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };

            //va a la API para ejecutar el stop de la tarea
            await _taskService.FinishTaskNotPlay(userInfo, idTarea);

            int projectId = int.Parse(hdfProyectIdClicked.Value);

            //se utiliza para la lista de tareas
            var response = await _taskService.ListTaskAsync(userInfo, projectId);
            
            //no se quita por que no se sabe para que sirve
            //lblCumpleanios.Visible = false;
            //widnow.Visible = false;
            //pnlProyectos.Visible = false;
            //pnlUsuarios.Visible = false;
            //pnlTareas.Visible = true;
            //pnlSearchTask.Visible = false;
            //divSearchTask.Visible = false;
            //pnlallobs.Visible = false;
                    
            //sin tareas
            if (!response.IsNull())
            {
                //recarga el pnl de tareas sin la tarea stopeada en el proyecto seleccionado, 
                //(si no quedaron tareas luego de stop, se recarga la pag)
                if (response.TaskItems.Count!=0)
                { 
                    
                tasks.DataSource = response.TaskItems;
                tasks.DataBind();

                divObservaciones.Visible = false;
                lblerrorupload.Visible = false;
                lbladdtask.Visible = false;
                pnlSearchTask.Visible = false;
                divSearchTask.Visible = false;
                //((Projects)Master).btnBackVisible = true;
                ((Projects)Master).enablerefresh = "#";

                var userresponse = await _userService.GetUserStatusAsync(userInfo);
                if (userresponse.UserType == "1")
                {
                   
                    PID.Value = hdfProyectIdClicked.Value;
                    pnlSearchTask.Visible = false;
                    divSearchTask.Visible = false;
                    divnewtask.Visible = true;
                    await GetUsersAll();

                }
                }
                else { Response.Redirect("project_X_Task.aspx"); }
            }
            else { Response.Redirect("project_X_Task.aspx"); }


        }

        protected async void addTask(object source, EventArgs e)
        {

            if (boxtarea.Text == "")
            {
                lbladdtask.Visible = true;
            }
            else
            {
                var cookie = Request.Cookies["session"];

                var userInfo = new UserInfo()
                {
                    User = cookie.Values["user"],
                    TOKEN = cookie.Values["token"]
                };

                var newtask = new NewTask();
                newtask.Projectid = int.Parse(PID.Value);
                newtask.TaskName = boxtarea.Text;
                newtask.UserCreator = userInfo.User;

                 string[] arg = new string[2];
                arg = ddlusuariostareas.SelectedItem.Text.ToString().Split(' ');

                newtask.Usertask = arg[0];

               
                TaskResult resultado = await _taskService.AddTaskAsync(userInfo, newtask);

                if (resultado.result == "OK")
                {
                    Response.Redirect("Project_X_Task.aspx", false);
                    lbladdtask.Visible = false;
                    boxtarea.Text = "";
                   
                }
                else
                {
                    lbladdtask.Text = resultado.result;
                    lbladdtask.Visible = true;

                }


            }

        }
      
        protected async void FillDll()
        {
            await GetUsers();
        }
     
        protected async void addObs(object source, EventArgs e)
        {
            if (cabbox.Text == "" || txtarea.Value == "")
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "showWarningObservation()", true);
                ///lblDebug.Visible = true;
            }
            else
            {
                var cookie = Request.Cookies["session"];

                var userInfo = new UserInfo()
                {
                    User = cookie.Values["user"],
                    TOKEN = cookie.Values["token"]
                };
                var userresponse = await _userService.GetUserStatusAsync(userInfo);

                var observation = new Observation();
                observation.Header = cabbox.Text;
                observation.observation = txtarea.Value;
                observation.Task = int.Parse(userresponse.TaskId);
                observation.TaskName = userresponse.TaskName;
                observation.Proyect = int.Parse(userresponse.ProjectId);
                observation.ProyectName = userresponse.ProjectName;
                ///  Response.Write(FileUpload1.FileName);
                /// Response.End();      PARAR TODO 

                if (FileUpload1.HasFile) { 
                    var fileStream = FileUpload1.PostedFile.InputStream;
                    var binaryReader = new System.IO.BinaryReader(fileStream);
                    var bytes = binaryReader.ReadBytes((Int32)fileStream.Length);
                    var base64String = Convert.ToBase64String(bytes, 0, bytes.Length);

                    observation.File = new Infrastructure.Models.File()
                    {
                        Name = Path.GetFileNameWithoutExtension(FileUpload1.PostedFile.FileName),
                        Extension = Path.GetExtension(FileUpload1.PostedFile.FileName),
                        Content = base64String
                       
                    };
                }
                else { observation.File = null; }

                //pnlTareaActiva.Value = Path.GetFileNameWithoutExtension(FileUpload1.PostedFile.FileName);


                // else
                //{

                //}

                TaskResult resultado = await _taskService.AddObsAsync(observation, userInfo);

                if (resultado.result == "OK")
                {
                    Response.Redirect("Project_X_Task.aspx", false);
                    lblerrorupload.Visible = false;
                    cabbox.Text = "";
                    txtarea.Value = "";
                }
                else
                {
                    lblerrorupload.Text = resultado.result;
                    lblerrorupload.Visible = true;

                }


            }


        }

        public async void ShowObs(object source, EventArgs e)
        {
            await GetObservations();
            pnlObservaciones.Visible = true;
            divObservaciones.Visible = false;
            lblerrorupload.Visible = false;
        }

        public async void ShowObsAll(object source, EventArgs e)
        {
            await GetAllObservations();
            // divCloseSearchTask.Visible = true;
            pnlProyectos.Visible = false;
            pnlallobs.Visible = true;
            pnlUsuarios.Visible = false;
            pnlSearchTask.Visible = false;
            HttpCookie cookie = Request.Cookies["lastpanel"];
            cookie.Values["panel"] = "showobs";
            Response.Cookies.Add(cookie);
        }

        public async void ShowHelp(object source, EventArgs e)
        {
            await GetUsers();
            divHelping.Visible = true;
            divObservaciones.Visible = false;
            lblerrorupload.Visible = false;
        }
        
       


        public void Hideobs(object source, EventArgs e)
        {
            pnlObservaciones.Visible = false;
            divObservaciones.Visible = true;
            divHelping.Visible = false;
            rptMostrarObs.Controls.Clear();
            ddlUsers.Controls.Clear();
            lblTaskHelp.Text = "";
        }

        public async void ShowSearch(object source, EventArgs e)
        {
            await GetAllUserTask();
            pnlSearchTask.Visible = true;
           // divCloseSearchTask.Visible = true;
            pnlProyectos.Visible = false;
            pnlallobs.Visible = false;
            pnlUsuarios.Visible = false;
            HttpCookie cookie = Request.Cookies["lastpanel"];
            cookie.Values["panel"] = "TaskSearch";
            Response.Cookies.Add(cookie);
        }

       

        public async void ShowProjectslist(object source, EventArgs e)
        {
            await GetUsersAll();
            HttpCookie cookie2 = Request.Cookies["lastpanel"];
            cookie2.Values["panel"] = "Project";
            var cookie = Request.Cookies["session"];
           
                var userInfo = new UserInfo()
                {
                    User = cookie.Values["user"],
                    TOKEN = cookie.Values["token"]
                };
            
                var userresponse = await _userService.GetUserStatusAsync(userInfo);
            if (userresponse.UserType=="2")
            {
                
                pnlSearchTask.Visible = false;
                pnlProyectos.Visible = false;
                pnlallobs.Visible = false;
                pnlUsuarios.Visible = true;
            }
            else
            {
                pnlSearchTask.Visible = false;
                pnlProyectos.Visible = true;
                pnlallobs.Visible = false;
                pnlUsuarios.Visible = false;
            }
            //  divCloseSearchTask.Visible = false;
            rptSearchTask.Controls.Clear();

            Response.Cookies.Add(cookie2);
        }

        public async void  StartHelp(object source, EventArgs e)
        {
            var cookie = Request.Cookies["session"];
            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };

            string[] arg = new string[2];
            arg = ddlUsers.SelectedItem.Text.ToString().Split(' ');
            var helper = new TaskHelper();
            helper.User = arg[0];
            if(tboxPassword.Text == "")
            {
                lblTaskHelp.Text = "USUARIO O CONTRASENIA INCORRECTA";
            }

            else
            { 
                   helper.Password = tboxPassword.Text;
                   var response = await _taskService.TaskHelpAsync(userInfo, helper);
    
                   if (response) lblTaskHelp.Text = "AYUDA INICIADA";
                   else lblTaskHelp.Text = "USUARIO O CONTRASENIA INCORRECTA";
                         tboxPassword.Text = "";
            }
        }



        protected async void Download_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            string id = e.CommandArgument.ToString();
          

            var cookie = Request.Cookies["session"];
            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };


            var response = await _taskService.DownloadFileAsync(userInfo, int.Parse(id));
           
            

            if (!response.IsNull())
            {


              

                System.Web.HttpResponse responses = System.Web.HttpContext.Current.Response;
                responses.ClearContent();
                responses.Clear();
               
                responses.ClearHeaders();

                responses.ContentType = "text/xml";
                responses.ContentEncoding = System.Text.Encoding.UTF8;

                responses.AddHeader("Content-Disposition",
                                   "attachment; filename=" + response.file.Name + "." +response.file.Extension + ";");
                Response.AddHeader("Content-Length", response.file.Content.Length.ToString());

                responses.TransmitFile(response.Path);
      
                responses.Flush();
                    responses.End();
                
            }
        }

        protected async void DownloadAll_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            string id = e.CommandArgument.ToString();
            var cookie = Request.Cookies["session"];
            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };


            var response = await _taskService.DownloadFileAsync(userInfo, int.Parse(id));

            if (!response.IsNull())
            {
                System.Web.HttpResponse responses = System.Web.HttpContext.Current.Response;
                responses.ClearContent();
                responses.Clear();

                responses.AddHeader("Content-Disposition",
                                   "attachment; filename=" + response.file.Name + "." + response.file.Extension + ";");
                responses.TransmitFile(response.Path);
                
                responses.Flush();
                responses.End();
            }
        }




        protected async void SearchTask_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            string[] arg = new string[4];
            arg = e.CommandArgument.ToString().Split(';');
            projectName = arg[1];
            await StartProyect(int.Parse(arg[0]));
            ActiveProject.Value = projectName;
            lblprojectname.Text = ActiveProject.Value;
            lblprojectname.Visible = true;

            await StartTask(int.Parse(arg[2]), int.Parse(e.CommandName.ToString()));
            if (lblError.Visible == false)
            {
                pnlTareas.Visible = false;
                divSearchTask.Visible = false;
                pnlallobs.Visible = false;
                rptMostrarObs.Controls.Clear();
                pnlTareaActiva.Visible = true;
                rptSearchTask.Controls.Clear();
                lbltaskid.Text = taskId.ToString();
                if (Extra == 0)
                {
                    lblextra.Text = "Normal";
                }
                else
                {
                    lblextra.Text = "Extra";
                }

                var cookie = Request.Cookies["session"];
                var userInfo = new UserInfo()
                {
                    User = cookie.Values["user"],
                    TOKEN = cookie.Values["token"]
                };

                var userresponse = await _userService.GetUserStatusAsync(userInfo);
                lblstarttime.Text = timeStart.ToString();
                lbltaskid.Text = userresponse.TaskName;
            }


        }

        protected async Task GetObservations()
        {

            var cookie = Request.Cookies["session"];
            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };

            var userresponse = await _userService.GetUserStatusAsync(userInfo);
            int id = int.Parse(userresponse.TaskId);
            var response = await _taskService.ShowObsAsync(userInfo,int.Parse(userresponse.TaskId));
           
            if (!response.IsNull())
            {
                rptMostrarObs.DataSource = response.ObsItems;
                rptMostrarObs.DataBind();

                
                //foreach (Control ctr in rptMostrarObs.Controls)
                //{
                //    if (ctr.GetType() == LinkButton.Equals())
                //    {
                //        ScriptManager.GetCurrent(this.Page).RegisterPostBackControl(ctr);
                //    }
                //}

            }
        }

        protected async Task GetAllObservations()
        {

            var cookie = Request.Cookies["session"];
            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };
           
           
            var response = await _projectService.ShowAllObsAsync(userInfo);

            if (!response.IsNull())
            {
                rptallobs.DataSource = response.ObsItems;
                rptallobs.DataBind();

            }
        }

        protected async void CorrectHour(object source, EventArgs e)
        {

            var cookie = Request.Cookies["session"];
            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };

            var userresponse = await _userService.GetUserStatusAsync(userInfo);
            var fecha = Convert.ToDateTime( userresponse.Start_Date);
            var newhora = fecha.Date;
                
                var response = await _userService.CorrectDay(userInfo, newhora.ToString("yyyyMMdd") + " " + txtHoraSalida.Value + ":00.000");

            if (response == "OK")
            {

                Cronometer.Visible = true;
                Response.Redirect("Project_X_Task.aspx", false);


            }
            else lblErrorday.Text = response;
                
                
            
            
            
        }

        protected async Task GetUsers()
        {
            var Users = new List<string>();
            Users = null;
            var cookie = Request.Cookies["session"];
            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };

         
            var response = await _userService.ListUsersAsync(userInfo, userInfo.User);
            
            if (!response.IsNull())
            {

               CreateDataBound(response);

            }
        }

        protected async Task GetUsersAll()
        {
            var Users = new List<string>();
            Users = null;
            var cookie = Request.Cookies["session"];
            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };


            var response = await _userService.ListUsersAllAsync(userInfo, userInfo.User);

            if (!response.IsNull())
            {

                CreateDataBound(response);

            }
        }
        //Llena los dropdown de usuarios y tareas de usuarios
        protected void CreateDataBound(List<UserSearch> Response)
        {
            DataTable dt = new DataTable();
            // Define the columns of the table.
            dt.Columns.Add(new DataColumn("Id", typeof(String)));
            dt.Columns.Add(new DataColumn("Usuario", typeof(String)));

           
            int i = Response.Count;
            for (int x = 0 ; x<i ; x++)
            {
                // Populate the table with sample values.
                dt.Rows.Add(CreateRow(Response[x].User, Response[x].UserId, dt));
              
            }
            // Create a DataView from the DataTable to act as the data source
            // for the DropDownList control.
            DataView dv = new DataView(dt);
            ddlUsers.DataSource = dv.Table;
            ddlUsers.DataTextField = "Id";
            ddlUsers.DataValueField = "Usuario";
            ddlUsers.DataBind();
            ddlusuariostareas.DataSource = dv.Table;
            ddlusuariostareas.DataTextField = "Id";
            ddlusuariostareas.DataValueField = "Usuario";
            ddlusuariostareas.DataBind();



        }

        protected void CreateDataBoundAll(List<UserSearch> Response)
        {
            DataTable dt = new DataTable();
            // Define the columns of the table.
            dt.Columns.Add(new DataColumn("Id", typeof(String)));
            dt.Columns.Add(new DataColumn("Usuario", typeof(String)));


            int i = Response.Count;
            for (int x = 0; x < i; x++)
            {
                // Populate the table with sample values.
                dt.Rows.Add(CreateRow(Response[x].User, Response[x].UserId, dt));

            }
            // Create a DataView from the DataTable to act as the data source
            // for the DropDownList control.
            DataView dv = new DataView(dt);
         
            


        }

        DataRow CreateRow(String Text, String Value, DataTable dt)
        {

            // Create a DataRow using the DataTable defined in the 
            // CreateDataSource method.
            DataRow dr = dt.NewRow();

            // This DataRow contains the ColorTextField and ColorValueField 
            // fields, as defined in the CreateDataSource method. Set the 
            // fields with the appropriate value. Remember that column 0 
            // is defined as ColorTextField, and column 1 is defined as 
            // ColorValueField.
            dr[0] = Text;
            dr[1] = Value;

            return dr;

        }



        protected async Task GetAllUserTask()
        {

            var cookie = Request.Cookies["session"];
            var userInfo = new UserInfo()
            {
                User = cookie.Values["user"],
                TOKEN = cookie.Values["token"]
            };

            var userresponse = await _userService.GetUserStatusAsync(userInfo);
            int Userid = int.Parse(userresponse.TaskId);
            var response = await _taskService.ListTaskSearchAsync(userInfo,userInfo.User);

            if (!response.IsNull())
            {
                rptSearchTask.DataSource = response.TaskItems;
                rptSearchTask.DataBind();

            }
        }

        protected async void addToDo (object source ,EventArgs e)
        {
            if (txtNewTodo.Text == "")
            {
            }
            else
            {
                var cookie = Request.Cookies["session"];

                var userInfo = new UserInfo()
                {
                    User = cookie.Values["user"],
                    TOKEN = cookie.Values["token"]
                };

                var newtask = new NewToDo();
                newtask.Descripcion = txtNewTodo.Text;
                newtask.User = userInfo.User;

                TaskResult resultado = await _taskService.AddToDoAsync(userInfo, newtask);

                if (resultado.result == "OK")
                {
                    Response.Redirect("Project_X_Task.aspx", false);
                }
                else
                {

                }


            }

        }



        protected async void ToDo_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            
                var cookie = Request.Cookies["session"];

                var userInfo = new UserInfo()
                {
                    User = cookie.Values["user"],
                    TOKEN = cookie.Values["token"]
                };
                if( e.CommandName == userInfo.User.ToLower())
                   {
                    var newtask = new NewToDo();
                   newtask.IdToDo = int.Parse(e.CommandArgument.ToString());
                     newtask.User = e.CommandName;
                     bool resultado = await _taskService.FinishToDoAsync(userInfo, newtask);

                        if (resultado)
                            {
                               Response.Redirect("Project_X_Task.aspx", false);
                              }
                          else
                            {
                             Response.Redirect("Project_X_Task.aspx", false);
                            }
                   }
                 else
                 {
                lblCumpleanios.Visible = false;
                pnlProyectos.Visible = false;
                pnlUsuarios.Visible = false;
                pnlTareas.Visible = false;
                pnlTareaActiva.Visible = false;
                pnlObservaciones.Visible = false;
                pnlCorregirSalida.Visible = false;
                divnewtask.Visible = false;
                divObservaciones.Visible = false;
                pnlSearchTask.Visible = false;
                Cronometer.Visible = false;
                divSearchTask.Visible = false;
                divnewtodotask.Visible = true;
                widnow.Visible = false;
                var projectresponse = await _projectService.ShowProjectsAsync(userInfo);
                ddlProyectos.DataSource= projectresponse.ProjectItems;
                ddlProyectos.DataTextField = "Project";
                ddlProyectos.DataValueField = "Id";
                ddlProyectos.DataBind();
                newtaskname.Value = e.CommandName.ToString();
                todotaskid.Value = e.CommandArgument.ToString();
            }

                
        }


        protected void CancelTodoTask(object source, EventArgs e)
        {
            widnow.Visible = true;
            lblCumpleanios.Visible = true;
            Response.Redirect("Project_X_Task.aspx", false);

        }


        protected async void addTaskTodo(object source, EventArgs e)
        {
           
          
                var cookie = Request.Cookies["session"];

                var userInfo = new UserInfo()
                {
                    User = cookie.Values["user"],
                    TOKEN = cookie.Values["token"]
                };
            
                var newtask = new NewToDoTask();
                newtask.IdProject = int.Parse(ddlProyectos.SelectedValue.ToString());
                newtask.Descripcion = newtaskname.Value;
                newtask.User = userInfo.User;
                newtask.IdToDo = int.Parse(todotaskid.Value.ToString());

                TaskResult resultado = await _taskService.AddTaskFromTodoAsync(userInfo, newtask);

                if (resultado.result == "OK")
                {
                    Response.Redirect("Project_X_Task.aspx", false);
                    lbladdtask.Visible = false;
                    boxtarea.Text = "";
                   
                }
                else
                {
                    lbladdtask.Text = resultado.result;
                    lbladdtask.Visible = true;

                }

            Response.Redirect("Project_X_Task.aspx", false);

        }

        protected void hdfsubtask_ValueChanged(object sender, EventArgs e)
        {

        }

        public static void llamarJS(System.Web.UI.Page Page, string funcion)
        {
            ScriptManager.RegisterStartupScript(Page,Page.GetType(), "Javascript", "playAudio(); ", true);
        }


        //protected async void uploadtask(object source, EventArgs e)
        //{
        //    int E=-1;
        //    if (lblextra.Text == "Normal" )
        //    {
        //        E = 0;
        //    }
        //    else if (lblextra.Text == "Extra")
        //    {
        //        E = 1;
        //    }
        //    TaskRequest request = new TaskRequest()
        //    {
        //        Id = int.Parse(lbltaskid.Text),

        //        IsExtra = E,
        //    };

        //    var cookie = Request.Cookies["session"];
        //    var userInfo = new UserInfo()
        //    {
        //        User = cookie.Values["user"],
        //        TOKEN = cookie.Values["token"]
        //    };

        //   await _taskService.UploadTaskAsync(userInfo,request);
        //}

    }
}

