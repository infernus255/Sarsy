﻿using PMS.Models.Models;
using PMS.Services.Helpers;
using PMS.Services.Services;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;

namespace PMS.Frontend
{
    public partial class DatosUsuarios : System.Web.UI.Page

    {
        private UserService _userService = new UserService();
        protected  void Page_Load(object sender, EventArgs e)
        {
            var cookie = Request.Cookies["session"];
            if (cookie == null)
            {
                Response.Redirect("Login.aspx", false);
            }
            else
            {
                var userInfo = new UserInfo()
                {
                    User = cookie.Values["user"],
                    TOKEN = cookie.Values["token"]
                };

              

            }
            
        }
    }
}