# Project Management System 
#### *Version de .NET Framework:* 4.5
#### *Lenguaje:* C Sharp

## Detalle de la solucion:

### *PMS.Frontend* -> UI de la aplicacion
### *PMS.Services* -> Bussiness Layer
### *PMS.Infrastructure* -> Models

## Documentacion

### Link de [Trello](https://trello.com/b/SkUVWOvb/project-management-system).
